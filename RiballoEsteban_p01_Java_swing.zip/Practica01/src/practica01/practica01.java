package practica01;

import java.time.LocalDate;
import java.awt.*;
import java.awt.event.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import javax.swing.*;

public class practica01 extends JFrame
{
    private String Nombre;
    private LocalDate FechaNac;
    private double Salario;

    private JLabel nombreLabel;
    private JLabel fechaLabel;
    private JLabel salarioLabel;

    private static String NombreString = "Nombre: ";
    private static String FechaString = "Fecha de Nacimiento: ";
    private static String SalarioString = "Salario: ";

    private TextField nombreField;
    private TextField fechaNacField;
    private TextField salarioField;
    
    private JLabel newNombreLabel;
    private JLabel newFechaLabel;
    private JLabel newSalarioLabel;

    private static String NewNombreString = "Nombre: ";
    private static String NewFechaString = "Fecha de Nacimiento: ";
    private static String NewSalarioString = "Salario: ";

    private TextField newNombreField;
    private TextField newFechaNacField;
    private TextField newSalarioField;
    
    private int indice = 0;
    
    private boolean focusIsSet = false;

    public practica01(ArrayList empleados) {
        super("Datos");

        Empleado emp = (Empleado) empleados.getFirst();
        Nombre = emp.getNombre() + " " + emp.getApellido1() + " " + emp.getApellido2();
        FechaNac = emp.getFechaNac();
        Salario = emp.getSalario();
        
        JButton button1 = new JButton("Inicio");
        button1.setMnemonic(KeyEvent.VK_1);
        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Empleado emp = (Empleado) empleados.getFirst();
                nombreField.setText(emp.getNombre() + " " + emp.getApellido1() + " " + emp.getApellido2());
                fechaNacField.setText(emp.getFechaNac().format(DateTimeFormatter.ISO_LOCAL_DATE));
                salarioField.setText(emp.getSalario() + "");
                indice = 0;
            }
        });
        
        JButton button2 = new JButton("<-");
        button2.setMnemonic(KeyEvent.VK_1);
        button2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(indice <= 0){
                    System.out.println("No hay un empleado anterior a este.");
                } else{
                    Empleado emp = (Empleado) empleados.get(indice - 1);
                    nombreField.setText(emp.getNombre() + " " + emp.getApellido1() + " " + emp.getApellido2());
                    fechaNacField.setText(emp.getFechaNac().format(DateTimeFormatter.ISO_LOCAL_DATE));
                    salarioField.setText(emp.getSalario() + "");
                    indice--;
                }
            }
        });
        
        JButton button3 = new JButton("->");
        button3.setMnemonic(KeyEvent.VK_1);
        button3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(indice >= empleados.size()-1){
                    
                } else{
                    Empleado emp = (Empleado) empleados.get(indice + 1);
                    nombreField.setText(emp.getNombre() + " " + emp.getApellido1() + " " + emp.getApellido2());
                    fechaNacField.setText(emp.getFechaNac().format(DateTimeFormatter.ISO_LOCAL_DATE));
                    salarioField.setText(emp.getSalario() + "");
                    indice++;
                }
            }
        });
        
        JButton button4 = new JButton("Fin");
        button4.setMnemonic(KeyEvent.VK_1);
        button4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Empleado emp = (Empleado) empleados.getLast();
                nombreField.setText(emp.getNombre() + " " + emp.getApellido1() + " " + emp.getApellido2());
                fechaNacField.setText(emp.getFechaNac().format(DateTimeFormatter.ISO_LOCAL_DATE));
                salarioField.setText(emp.getSalario() + "");
                indice = empleados.size()-1;
            }
        });
        
        nombreLabel = new JLabel(NombreString);
        fechaLabel = new JLabel(FechaString);
        salarioLabel = new JLabel(SalarioString);

        nombreField = new TextField(20);
        nombreField.setEditable(false);
        nombreField.setForeground(Color.DARK_GRAY);
        nombreField.setText(emp.getNombre() + " " + emp.getApellido1() + " " + emp.getApellido2());
        
        fechaNacField = new TextField(20);
        fechaNacField.setEditable(false);
        fechaNacField.setForeground(Color.DARK_GRAY);
        fechaNacField.setText(FechaNac.format(DateTimeFormatter.ISO_DATE));
        
        salarioField = new TextField(20);
        salarioField.setEditable(false);
        salarioField.setForeground(Color.DARK_GRAY);
        salarioField.setText(Salario + "");

        JPanel labelPane = new JPanel();
        labelPane.setLayout(new GridLayout(0, 1));
        labelPane.add(nombreLabel);
        labelPane.add(fechaLabel);
        labelPane.add(salarioLabel);

        JPanel fieldPane = new JPanel();
        fieldPane.setLayout(new GridLayout(0, 1));
        fieldPane.add(nombreField);
        fieldPane.add(fechaNacField);
        fieldPane.add(salarioField);
        
        JPanel buttonPane = new JPanel();
        buttonPane.setLayout(new GridLayout(1,0));
        buttonPane.add(button1);
        buttonPane.add(button2);
        buttonPane.add(button3);
        buttonPane.add(button4);

        JPanel contentPane = new JPanel();
        contentPane.setBorder(
               BorderFactory.createEmptyBorder(20, 20, 20, 20));
        contentPane.setLayout(new BorderLayout());
        contentPane.add(labelPane, BorderLayout.CENTER);
        contentPane.add(fieldPane, BorderLayout.EAST);
        contentPane.add(buttonPane, BorderLayout.SOUTH);


        setContentPane(contentPane);

    }
    public static void main(String[] args) {
        Empresa e = new Empresa();
        
        e.addEmpleado("Juan", "Riballo", "Moreno", LocalDate.of(2007, 4, 12), 1247.24);
        e.addEmpleado("Carlos", "Martinez", "Kolo", LocalDate.of(2000, 1, 27), 2903.32);
        e.addEmpleado("Hugo", "Jugos", "Jalos", LocalDate.of(1999, 11, 1), 1357.20);
        e.addEmpleado("Virginia", "Lacero", "Moreno", LocalDate.of(1984, 2, 12), 1800.99);
        e.addEmpleado("Esteban", "Riballo", "Moreno", LocalDate.of(2004, 6, 21), 2097.64);
        
        final practica01 app = new practica01(e.getEmpleados());

        app.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
        app.pack();
        app.setVisible(true);
    }
}
