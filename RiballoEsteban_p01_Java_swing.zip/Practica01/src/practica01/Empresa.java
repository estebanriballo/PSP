package practica01;

import java.time.*;
import java.util.*;
public class Empresa {
    private ArrayList<Empleado> empleados = new ArrayList<Empleado>();

    public Empresa() {
    }

    public void addEmpleado(String nombre, String apellido1, String apellido2, LocalDate FechaNac, double salario){
        Empleado e = new Empleado(nombre, apellido1, apellido2, FechaNac, salario);
        
        empleados.add(e);
    }

    public ArrayList<Empleado> getEmpleados() {
        return empleados;
    }
}
