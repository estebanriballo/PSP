/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ayuda.psp02;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author bosque
 */
public class PanelVer extends javax.swing.JPanel {
   //Valores para los campos de texto
    private int numero = 0;
    private int doble = 0;
    // private NumberFormat integerFormatter;

    //Etiquetas para identificar los campos de texto
    private JLabel numeroLabel;
    private JLabel dobleLabel;

    //Cadenas para las etiquetas
    private static String numeroString = "Número: ";
    private static String dobleString = "El doble es: ";

    //Text fields para introducir números
    private TextField numeroField;
    private TextField dobleField;

    public PanelVer() {
        super();
        
        //Crea las etiquetas.
        numeroLabel = new JLabel(numeroString);
        dobleLabel = new JLabel(dobleString);

        //Campo donde vamos a introducir el número
        numeroField = new TextField(10);

        //Lo que hace cuando pulsamos Enter
        numeroField.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e) {
                String n = numeroField.getText();
                try {
                    numero = Integer.parseInt(n);
                    doble = numero * 2;
                    dobleField.setText(""+doble);
                } catch(NumberFormatException nfe) {
                    //Mensaje de error
                    System.err.println(
                         "No es un entero: '"+n+"'");
                }
            }
        });

        //Campo que nos muestra el doble del numero introducido
        dobleField = new TextField(10);
        dobleField.setEditable(false);
        dobleField.setForeground(Color.red);

        //Dispone la geometría de las etiquetas en un panel
        JPanel labelPane = new JPanel();
        labelPane.setLayout(new GridLayout(0, 1));
        labelPane.add(numeroLabel);
        labelPane.add(dobleLabel);

        //Dispone los campos de texto en otro panel
        JPanel fieldPane = new JPanel();
        fieldPane.setLayout(new GridLayout(0, 1));
        fieldPane.add(numeroField);
        fieldPane.add(dobleField);

        //Incluye los dos paneles en otro panel,
        //etiquetas a la izquierda
        //y campos de texto a la derecha.
        //JPanel contentPane = new JPanel();
        setBorder(
               BorderFactory.createEmptyBorder(20, 20, 20, 20));
        setLayout(new BorderLayout());
        add(labelPane, BorderLayout.CENTER);
        add(fieldPane, BorderLayout.EAST);
    }
}
