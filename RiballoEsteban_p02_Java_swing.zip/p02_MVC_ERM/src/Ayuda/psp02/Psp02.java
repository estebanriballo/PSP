/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ayuda.psp02;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Psp02 extends JFrame implements ActionListener{

    private JMenuBar menuBar;
    private JMenu menuA1, menuB1,  menu2, menu3;
    private JMenuItem menuItem21, menuItem22, menuItem31, menuItem32;

    public Psp02() {

        /* Creamos el JMenuBar y lo asociamos con el JFrame */
        menuBar=new JMenuBar();
        setJMenuBar(menuBar);

        /* Creamos el primer JMenu y lo pasamos como parámetro al JMenuBar mediante el método add */
        menuA1=new JMenu("Opciones");
        menuBar.add(menuA1);
                
        /* Creamos el segundo y tercer objetos de la clase JMenu y los asociamos con el primer JMenu creado */
        menu2=new JMenu("Tamaño de la ventana");
        menuA1.add(menu2);
        menu3=new JMenu("Color de fondo");
        menuA1.add(menu3);

        /* Creamos los dos primeros objetos de la clase JMenuItem y los asociamos con el segundo JMenu */
        menuItem21=new JMenuItem("640*480");
        menu2.add(menuItem21);
        menuItem21.addActionListener(this);
        menuItem22=new JMenuItem("1024*768");
        menu2.add(menuItem22);
        menuItem22.addActionListener(this);

        /* Creamos los otros dos objetos de la clase JMenuItem y los  asociamos con el tercer JMenu */
        menuItem31=new JMenuItem("Rojo");
        menu3.add(menuItem31);
        menuItem31.addActionListener(this);
        menuItem32=new JMenuItem("Verde");
        menu3.add(menuItem32);
        menuItem32.addActionListener(this);
        
        /* Otra opcion del JMenuBar  */
        /* Creamos el segundo JMenu y lo pasamos como parámetro al JMenuBar mediante el método add */
        menuB1=new JMenu("Ayuda");    
        menuBar.add(menuB1);
        
        //Configurar y mostrar JFrame
        initPantalla();
    }

    private void initPantalla() {
        setLayout(null); //Layout absoluto
        setTitle("PSP práctica 2"); //Título del JFrame
        setSize(300, 200); //Dimensiones del JFrame
        setResizable(false); //No redimensionable
        // Poner un panel. Comenta la linea inferior y ejecuta.        
        setContentPane(new PanelVer());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //Cerrar proceso al cerrar ventana
        setVisible(true); //Mostrar JFrame
    }

    /* Método que implementa las acciones de cada ítem de menú */
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==menuItem21) {
            setSize(640,480);
        }
        if (e.getSource()==menuItem22) {
            setSize(1024,768);
        }
        if (e.getSource()==menuItem31) {
            getContentPane().setBackground(new Color(255,0,0));
        }
        if (e.getSource()==menuItem32) {
            getContentPane().setBackground(new Color(0,255,0));
        }
    }

    public static void main(String[] args) {

        new Psp02();

    }

}
    

