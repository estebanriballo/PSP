package Modelo;
import java.util.*;
import java.time.*;
import java.time.format.DateTimeFormatter;

public class Empleado {
    private static int contadorEmpleados = 0;
    private int numeroEmpleado;
    private String nombre;
    private LocalDate fechaNacimiento;
    private double sueldo;
    private double sueldoMaximo;
    private Empleado siguiente;
    private static Empleado inicial = null;
    private static Empleado actual = null;

    public Empleado(String nombre, LocalDate fechaNacimiento, double sueldo, double sueldoMaximo) {
        this.numeroEmpleado = ++contadorEmpleados;
        this.nombre = nombre;
        this.fechaNacimiento = fechaNacimiento;
        this.sueldo = sueldo;
        this.sueldoMaximo = sueldoMaximo;
        this.siguiente = null;
    }

    public static Empleado mostrarEmpleadoSiguiente(){
        if (actual != null && actual.siguiente != null) {
            actual = actual.siguiente;
        }
        return Empleado.actual;
    }
    
    public static Empleado mostrarEmpleadoAnterior(){
        boolean l = true;
        Empleado ant = Empleado.actual;
        while(l){
            if(actual.siguiente != ant){
                if(Empleado.actual.siguiente == null){
                    Empleado.actual = Empleado.inicial;
                }else{
                    Empleado.actual = Empleado.actual.siguiente;
                }
            }else{
                l = false;
            }
        }
        return Empleado.actual;
    }
    
    public static Empleado mostrarEmpleadoFinal(){
        boolean l = true;
        while(l){
            if(Empleado.actual.siguiente != null){
                Empleado.actual = Empleado.actual.siguiente;
            }else{
                l = false;
            }
        }
        return Empleado.actual;
    }
    
    public static final Empleado mostrarEmpleadoInicial(){
        Empleado.actual = Empleado.inicial;
        return Empleado.inicial;
    }
    
    public static Empleado mostrarEmpleadoActual() {
        return Empleado.actual;
    }
    
    public static void agregarEmpleado(Empleado nuevoEmpleado) {
        if (inicial == null) {
            inicial = nuevoEmpleado;
            actual = nuevoEmpleado;
            
        } else {
            Empleado temp = inicial;
            while (temp.siguiente != null) {
                temp = temp.siguiente;
            }
            temp.siguiente = nuevoEmpleado;
        }
    }

    public static void avanzarAlSiguiente() {
        if (actual != null && actual.siguiente != null) {
            actual = actual.siguiente;
            mostrarEmpleadoActual();
        } else {
            System.out.println("No hay más empleados en la lista.");
        }
    }

    public static void mostrarTodosLosEmpleados() {
        Empleado temp = inicial;
        while (temp != null) {
            System.out.println("Empleado: " + temp.nombre + " (ID: " + temp.numeroEmpleado + ")");
            System.out.println("Fecha de Nacimiento: " + temp.fechaNacimiento.format(DateTimeFormatter.ISO_DATE));
            System.out.println("Sueldo: " + temp.sueldo);
            System.out.println("Sueldo Máximo: " + temp.sueldoMaximo);
            temp = temp.siguiente;
        }
    }

    public static int getContadorEmpleados() {
        return contadorEmpleados;
    }

    public static void setContadorEmpleados(int contadorEmpleados) {
        Empleado.contadorEmpleados = contadorEmpleados;
    }

    public int getNumeroEmpleado() {
        return numeroEmpleado;
    }

    public void setNumeroEmpleado(int numeroEmpleado) {
        this.numeroEmpleado = numeroEmpleado;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public LocalDate getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(LocalDate fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public double getSueldo() {
        return sueldo;
    }

    public void setSueldo(double sueldo) {
        this.sueldo = sueldo;
    }

    public double getSueldoMaximo() {
        return sueldoMaximo;
    }

    public void setSueldoMaximo(double sueldoMaximo) {
        this.sueldoMaximo = sueldoMaximo;
    }

    public Empleado getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(Empleado siguiente) {
        this.siguiente = siguiente;
    }

    public static Empleado getInicial() {
        return inicial;
    }

    public static void setInicial(Empleado inicial) {
        Empleado.inicial = inicial;
    }

    public static Empleado getActual() {
        return actual;
    }

    public static void setActual(Empleado actual) {
        Empleado.actual = actual;
    }
    
    
}
