package Controlador;

import java.awt.*;
import javax.swing.*;

public class Error {
    public static boolean comprobarFecha(int año){
        if(año >= 1915 && año <= 2015){
            return true;
        }
        else{
            return false;
        }
    }
    public static boolean comprobarSalario(double salario, double salarioMax){
        if(salario < salarioMax){
            return true;
        }
        else{
            return false;
        }
    }
    
    public static void mostrarError(JLabel labelError, String mensaje) {
        labelError.setText(mensaje);
        labelError.setForeground(Color.RED);
    }
}
