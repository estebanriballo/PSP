package p02_mvc_erm;

import java.awt.*;
import java.awt.GridLayout;
import javax.swing.*;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class PanAyuda extends JPanel {
    private JLabel ayudaLabel;
    private JLabel ayuda1Label;
    
    private static String ayudaString = "Programa creado por Esteban Riballo Moreno";
    private static String ayuda1String = "Para Consultas estebanriballo@gmail.com o 667802822";
    
    public PanAyuda(){
        ayudaLabel = new JLabel(ayudaString);
        ayuda1Label = new JLabel(ayuda1String);
        
        JPanel labelPane = new JPanel();
        labelPane.setLayout(new GridLayout(0, 1));
        labelPane.add(ayudaLabel);
        labelPane.add(ayuda1Label);
        
        this.setBorder(
               BorderFactory.createEmptyBorder(20, 20, 20, 20));
        this.setLayout(new BorderLayout());
        this.add(labelPane, BorderLayout.CENTER);
    }
}
