package p02_mvc_erm;
import Modelo.Empleado;
import static Modelo.Empleado.*;
import java.util.*;
import javax.swing.*;
import java. time.*;
import java.awt.*;
import java.awt.event.*;
import java.time.format.DateTimeFormatter;

public class JMenuBar extends JFrame implements ActionListener{
    
    private javax.swing.JMenuBar menuBar;
    private JMenu menu1;
    private JMenuItem menuItem1, menuItem2, menuItem3;
    
    public JMenuBar() {
        menuBar = new javax.swing.JMenuBar();
        setJMenuBar(menuBar);
        
        menu1 = new JMenu("Paneles");
        menuBar.add(menu1);
        
        menuItem1=new JMenuItem("Ver Empleados");
        menu1.add(menuItem1);
        menuItem1.addActionListener(this);
        menuItem2=new JMenuItem("Alta Empleados");
        menu1.add(menuItem2);
        menuItem2.addActionListener(this);
        menuItem3=new JMenuItem("Info");
        menu1.add(menuItem3);
        menuItem3.addActionListener(this);
        
        initPantalla();
    }
    private void initPantalla() {
        setLayout(null); //Layout absoluto
        setTitle("PSP práctica 2"); //Título del JFrame
        setSize(500, 500); //Dimensiones del JFrame
        setResizable(true); //No redimensionable
        this.setContentPane(new PanAlta());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //Cerrar proceso al cerrar ventana
        setVisible(true); //Mostrar JFrame
    }
    public static void main(String[] args) {
        new JMenuBar();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==menuItem1) {
            this.setContentPane(new PanelVer());
        }
        if (e.getSource()==menuItem2) {
            this.setContentPane(new PanAlta());
        }
        if (e.getSource()==menuItem3) {
            this.setContentPane(new PanAyuda());
        }
        this.pack();
        this.repaint();
    }
}
