package p02_mvc_erm;

import Controlador.Error;
import Modelo.Empleado;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.time.LocalDate;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class PanAlta extends JPanel {
    private String nombre;
    private LocalDate fechaNacimiento;
    private double sueldo;
    private double sueldoMaximo;
    
    private JLabel nombreLabel;
    private JLabel fechaLabel;
    private JLabel salarioLabel;
    private JLabel salarioMaxLabel;
    
    private static String NombreString = "Nombre: ";
    private static String FechaString = "Fecha de Nacimiento (XXXX/MM/DD): ";
    private static String SalarioString = "Salario: ";
    private static String SalarioMaxString = "Salario Máximo: ";
    
    private TextField nombreField;
    private TextField fechaNacField;
    private TextField salarioField;
    private TextField salarioMaxField;
    
    JButton button1;
    JButton button2;
    
    public PanAlta(){
        button1 = new JButton("Borrar Todo");
        button1.setMnemonic(KeyEvent.VK_1);
        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                nombreField.setText("");
                fechaNacField.setText("");
                salarioField.setText("");
                salarioMaxField.setText("");
            }
        });
        
        button2 = new JButton("Dar de Alta");
        button2.setMnemonic(KeyEvent.VK_1);
        button2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nom = nombreField.getText();
                String fechaNac = fechaNacField.getText();
                String salario = salarioField.getText();
                String salarioMax = salarioMaxField.getText();
                
                if(Error.comprobarFecha(Integer.parseInt(fechaNac.substring(0, 4))) == false){
                    JLabel ErrorLabel1 = new JLabel();
                    String a = "El año debe estar entre 1915 y 2015";
                    
                    Error.mostrarError(nombreLabel, a);
                }else if(Error.comprobarSalario(Double.parseDouble(salario), Double.parseDouble(salarioMax)) == false){
                    JLabel ErrorLabel1 = new JLabel();
                    String a = "El salario es mayor al salario maximo";
                    
                    Error.mostrarError(nombreLabel, a);
                }else{
                    LocalDate fn = LocalDate.of(Integer.parseInt(fechaNac.substring(0, 4)), Integer.parseInt(fechaNac.substring(6, 7)), Integer.parseInt(fechaNac.substring(9, 10)));
                    double sal = Double.parseDouble(salario);
                    double salMax = Double.parseDouble(salarioMax);
                
                    Empleado emp = new Empleado(nom, fn, sal, salMax);
                    Empleado.agregarEmpleado(emp);
                
                    System.out.println("Empleado Creado!!!");
                
                    nombreField.setText("");
                    fechaNacField.setText("");
                    salarioField.setText("");
                    salarioMaxField.setText("");
                }
            }
        });
        
        nombreLabel = new JLabel(NombreString);
        fechaLabel = new JLabel(FechaString);
        salarioLabel = new JLabel(SalarioString);
        salarioMaxLabel = new JLabel(SalarioMaxString);

        nombreField = new TextField(20);
        nombreField.setEditable(true);
        nombreField.setForeground(Color.DARK_GRAY);
        
        fechaNacField = new TextField(20);
        fechaNacField.setEditable(true);
        fechaNacField.setForeground(Color.DARK_GRAY);
        
        salarioField = new TextField(20);
        salarioField.setEditable(true);
        salarioField.setForeground(Color.DARK_GRAY);
        
        salarioMaxField = new TextField(20);
        salarioMaxField.setEditable(true);
        salarioMaxField.setForeground(Color.DARK_GRAY);
        
        JPanel labelPane = new JPanel();
        labelPane.setLayout(new GridLayout(0, 1));
        labelPane.add(nombreLabel);
        labelPane.add(fechaLabel);
        labelPane.add(salarioLabel);
        labelPane.add(salarioMaxLabel);

        JPanel fieldPane = new JPanel();
        fieldPane.setLayout(new GridLayout(0, 1));
        fieldPane.add(nombreField);
        fieldPane.add(fechaNacField);
        fieldPane.add(salarioField);
        fieldPane.add(salarioMaxField);
        
        JPanel buttonPane = new JPanel();
        buttonPane.setLayout(new GridLayout(1,0));
        buttonPane.add(button1);
        buttonPane.add(button2);
        
        this.setBorder(
               BorderFactory.createEmptyBorder(20, 20, 20, 20));
        this.setLayout(new BorderLayout());
        this.add(labelPane, BorderLayout.CENTER);
        this.add(fieldPane, BorderLayout.EAST);
        this.add(buttonPane, BorderLayout.SOUTH);
    }
}
