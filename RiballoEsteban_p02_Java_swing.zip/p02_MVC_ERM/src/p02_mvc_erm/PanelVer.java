package p02_mvc_erm;
import Modelo.Empleado;
import java.util.*;
import javax.swing.*;
import java. time.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.time.*;
import java.time.format.DateTimeFormatter;

public class PanelVer extends JPanel {
    
    private String nombre;
    private LocalDate fechaNacimiento;
    private double sueldo;
    private double sueldoMaximo;
    
    private JLabel nombreLabel;
    private JLabel fechaLabel;
    private JLabel salarioLabel;
    private JLabel salarioMaxLabel;
    
    private static String NombreString = "Nombre: ";
    private static String FechaString = "Fecha de Nacimiento: ";
    private static String SalarioString = "Salario: ";
    private static String SalarioMaxString = "Salario Máximo: ";
    
    private TextField nombreField;
    private TextField fechaNacField;
    private TextField salarioField;
    private TextField salarioMaxField;
    
    JButton button1;
    JButton button2;
    JButton button3;
    JButton button4;
    
    Empleado emp = Empleado.mostrarEmpleadoActual();
    
    public PanelVer(){
        
        button1 = new JButton("Inicio");
        button1.setMnemonic(KeyEvent.VK_1);
        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                button2.setEnabled(true);
                button3.setEnabled(true);
                emp = Empleado.mostrarEmpleadoInicial();
                nombreField.setText(emp.getNombre());
                fechaNacField.setText(emp.getFechaNacimiento().toString());
                salarioField.setText(""+ emp.getSueldo());
                salarioMaxField.setText("" + emp.getSueldoMaximo());
            }
        });
        
        button2 = new JButton("<-");
        button2.setMnemonic(KeyEvent.VK_1);
        button2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(Empleado.getActual().equals(Empleado.getInicial())){
                    button2.setEnabled(false);
                }else{
                    button2.setEnabled(true);
                    button3.setEnabled(true);
                    emp = Empleado.mostrarEmpleadoAnterior();
                    nombreField.setText(emp.getNombre());
                    fechaNacField.setText(emp.getFechaNacimiento().toString());
                    salarioField.setText(""+ emp.getSueldo());
                    salarioMaxField.setText("" + emp.getSueldoMaximo());
                }
                
            }
        });
        
        button3 = new JButton("->");
        button3.setMnemonic(KeyEvent.VK_1);
        button3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(Empleado.getActual().equals(Empleado.mostrarEmpleadoFinal())){
                    button3.setEnabled(false);
                }else{
                    button2.setEnabled(true);
                    button3.setEnabled(true);
                    emp = Empleado.mostrarEmpleadoSiguiente();
                    nombreField.setText(emp.getNombre());
                    fechaNacField.setText(emp.getFechaNacimiento().toString());
                    salarioField.setText(""+ emp.getSueldo());
                    salarioMaxField.setText("" + emp.getSueldoMaximo());
                }
            }
        });
        
        button4 = new JButton("Fin");
        button4.setMnemonic(KeyEvent.VK_1);
        button4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                button2.setEnabled(true);
                button3.setEnabled(true);
                emp = Empleado.mostrarEmpleadoFinal();
                nombreField.setText(emp.getNombre());
                fechaNacField.setText(emp.getFechaNacimiento().toString());
                salarioField.setText(""+ emp.getSueldo());
                salarioMaxField.setText("" + emp.getSueldoMaximo());
            }
        });
        
        nombreLabel = new JLabel(NombreString);
        fechaLabel = new JLabel(FechaString);
        salarioLabel = new JLabel(SalarioString);
        salarioMaxLabel = new JLabel(SalarioMaxString);

        nombreField = new TextField(20);
        nombreField.setEditable(false);
        nombreField.setForeground(Color.DARK_GRAY);
        
        fechaNacField = new TextField(20);
        fechaNacField.setEditable(false);
        fechaNacField.setForeground(Color.DARK_GRAY);
        
        salarioField = new TextField(20);
        salarioField.setEditable(false);
        salarioField.setForeground(Color.DARK_GRAY);
        
        salarioMaxField = new TextField(20);
        salarioMaxField.setEditable(false);
        salarioMaxField.setForeground(Color.DARK_GRAY);
        
        if(Empleado.getInicial() == null){
            nombreField.setText("No existe aun ningun empleado registrado");
            fechaNacField.setText("");
            salarioField.setText("");
            salarioMaxField.setText("");
            button1.setEnabled(false);
            button2.setEnabled(false);
            button3.setEnabled(false);
            button4.setEnabled(false);
        }else{
            nombreField.setText(emp.getNombre());
            fechaNacField.setText(emp.getFechaNacimiento().toString());
            salarioField.setText(""+ emp.getSueldo());
            salarioMaxField.setText("" + emp.getSueldoMaximo());
            button1.setEnabled(true);
            button2.setEnabled(true);
            button3.setEnabled(true);
            button4.setEnabled(true);
        }
        
        JPanel labelPane = new JPanel();
        labelPane.setLayout(new GridLayout(0, 1));
        labelPane.add(nombreLabel);
        labelPane.add(fechaLabel);
        labelPane.add(salarioLabel);
        labelPane.add(salarioMaxLabel);

        JPanel fieldPane = new JPanel();
        fieldPane.setLayout(new GridLayout(0, 1));
        fieldPane.add(nombreField);
        fieldPane.add(fechaNacField);
        fieldPane.add(salarioField);
        fieldPane.add(salarioMaxField);
        
        JPanel buttonPane = new JPanel();
        buttonPane.setLayout(new GridLayout(1,0));
        buttonPane.add(button1);
        buttonPane.add(button2);
        buttonPane.add(button3);
        buttonPane.add(button4);
        
        this.setBorder(
               BorderFactory.createEmptyBorder(20, 20, 20, 20));
        this.setLayout(new BorderLayout());
        this.add(labelPane, BorderLayout.CENTER);
        this.add(fieldPane, BorderLayout.EAST);
        this.add(buttonPane, BorderLayout.SOUTH);
    }
}
